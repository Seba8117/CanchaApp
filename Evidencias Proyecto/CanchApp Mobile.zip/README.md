
  # CanchApp Mobile

  This is a code bundle for CanchApp Mobile. The original project is available at https://www.figma.com/design/dlIlfJdzdFSY4S409siP73/CanchApp-Mobile.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  