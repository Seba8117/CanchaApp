import { useState } from 'react';
import { Building, Calendar, Trophy, Users, Plus, TrendingUp, Clock, MapPin, Settings, LogOut, MoreVertical, AlertTriangle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from './ui/dropdown-menu';
import { AppHeader } from './AppHeader';
import logoIcon from 'figma:asset/66394a385685f7f512fa4478af752d1d9db6eb4e.png';

interface OwnerDashboardProps {
  onNavigate: (screen: string, data?: any) => void;
  onLogout?: () => void;
}

export function OwnerDashboard({ onNavigate, onLogout }: OwnerDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');

  // Mock data para el dashboard
  const stats = {
    totalCourts: 5,
    totalBookings: 142,
    monthlyRevenue: 850000,
    activeTournaments: 3,
    averageRating: 4.7
  };

  const courts = [
    {
      id: 1,
      name: 'Cancha Principal',
      sport: 'Fútbol',
      surface: 'Césped sintético',
      capacity: 22,
      pricePerHour: 25000,
      status: 'available',
      bookingsToday: 6,
      rating: 4.8
    },
    {
      id: 2,
      name: 'Cancha Básquetball',
      sport: 'Básquetball',
      surface: 'Madera',
      capacity: 10,
      pricePerHour: 20000,
      status: 'occupied',
      bookingsToday: 4,
      rating: 4.6
    },
    {
      id: 3,
      name: 'Cancha Tenis Norte',
      sport: 'Tenis',
      surface: 'Arcilla',
      capacity: 4,
      pricePerHour: 15000,
      status: 'maintenance',
      bookingsToday: 0,
      rating: 4.9
    }
  ];

  const recentBookings = [
    {
      id: 1,
      courtName: 'Cancha Principal',
      playerName: 'Carlos Mendoza',
      date: 'Hoy',
      time: '18:00 - 20:00',
      amount: 50000,
      status: 'confirmed'
    },
    {
      id: 2,
      courtName: 'Cancha Básquetball',
      playerName: 'Ana García',
      date: 'Mañana',
      time: '16:00 - 17:30',
      amount: 30000,
      status: 'pending'
    },
    {
      id: 3,
      courtName: 'Cancha Principal',
      playerName: 'Los Tigres FC',
      date: '15 Sep',
      time: '20:00 - 22:00',
      amount: 50000,
      status: 'completed'
    }
  ];

  const tournaments = [
    {
      id: 1,
      name: 'Copa Primavera Fútbol',
      sport: 'Fútbol',
      participants: 16,
      startDate: '20 Sep',
      prize: 500000,
      status: 'active'
    },
    {
      id: 2,
      name: 'Torneo Básquetball Amateur',
      sport: 'Básquetball',
      participants: 8,
      startDate: '25 Sep',
      prize: 300000,
      status: 'registration'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-100 text-green-700';
      case 'occupied': return 'bg-red-100 text-red-700';
      case 'maintenance': return 'bg-yellow-100 text-yellow-700';
      case 'confirmed': return 'bg-green-100 text-green-700';
      case 'pending': return 'bg-yellow-100 text-yellow-700';
      case 'completed': return 'bg-gray-100 text-gray-700';
      case 'active': return 'bg-blue-100 text-blue-700';
      case 'registration': return 'bg-orange-100 text-orange-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'available': return 'Disponible';
      case 'occupied': return 'Ocupada';
      case 'maintenance': return 'Mantenimiento';
      case 'confirmed': return 'Confirmada';
      case 'pending': return 'Pendiente';
      case 'completed': return 'Completada';
      case 'active': return 'Activo';
      case 'registration': return 'Inscripciones';
      default: return status;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <AppHeader 
        title="Panel de Control" 
        showLogo={true}
        rightContent={
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-[#00a884] border-[#00a884]"
                >
                  <MoreVertical size={16} />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onNavigate('report-team')}>
                  <AlertTriangle size={16} className="mr-2" />
                  Reportar Equipo
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onNavigate('owner-settings')}>
                  <Settings size={16} className="mr-2" />
                  Configuración
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  className="text-red-600 focus:text-red-600"
                  onClick={() => {
                    if (window.confirm('¿Estás seguro que quieres cerrar tu sesión empresarial?')) {
                      onLogout?.();
                    }
                  }}
                >
                  <LogOut size={16} className="mr-2" />
                  Cerrar Sesión
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        }
      />

      <div className="p-4">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <Card className="bg-gradient-to-r from-[#00a884] to-[#00a884]/80 text-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-90">Canchas</p>
                  <p className="text-2xl font-bold">{stats.totalCourts}</p>
                </div>
                <Building size={24} className="opacity-80" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-[#f4b400] to-[#f4b400]/80 text-[#172c44]">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-90">Reservas</p>
                  <p className="text-2xl font-bold">{stats.totalBookings}</p>
                </div>
                <Calendar size={24} className="opacity-80" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-[#172c44] to-[#172c44]/80 text-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-90">Ingresos</p>
                  <p className="text-lg font-bold">${(stats.monthlyRevenue / 1000).toFixed(0)}k</p>
                </div>
                <TrendingUp size={24} className="opacity-80" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-purple-500 to-purple-400 text-white">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm opacity-90">Torneos</p>
                  <p className="text-2xl font-bold">{stats.activeTournaments}</p>
                </div>
                <Trophy size={24} className="opacity-80" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Resumen</TabsTrigger>
            <TabsTrigger value="courts">Canchas</TabsTrigger>
            <TabsTrigger value="tournaments">Torneos</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-[#172c44]">Reservas Recientes</h2>
              <Button variant="ghost" size="sm" className="text-[#00a884]">
                Ver Todas
              </Button>
            </div>

            {recentBookings.map((booking) => (
              <Card key={booking.id}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-[#172c44]">{booking.courtName}</h3>
                        <Badge className={`text-xs ${getStatusColor(booking.status)}`}>
                          {getStatusText(booking.status)}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-1">{booking.playerName}</p>
                      <div className="flex items-center gap-3 text-sm text-gray-600">
                        <span>{booking.date}</span>
                        <span className="flex items-center gap-1">
                          <Clock size={14} />
                          {booking.time}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-[#172c44] font-semibold">
                        ${booking.amount.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          {/* Courts Tab */}
          <TabsContent value="courts" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-[#172c44]">Mis Canchas</h2>
              <Button 
                size="sm" 
                className="bg-[#00a884] hover:bg-[#00a884]/90 text-white"
                onClick={() => onNavigate('add-court')}
              >
                <Plus size={16} className="mr-2" />
                Agregar Cancha
              </Button>
            </div>

            {courts.map((court) => (
              <Card key={court.id}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-[#172c44]">{court.name}</h3>
                        <Badge className={`text-xs ${getStatusColor(court.status)}`}>
                          {getStatusText(court.status)}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span>{court.sport}</span>
                        <span>{court.surface}</span>
                        <span className="flex items-center gap-1">
                          <Users size={14} />
                          {court.capacity} personas
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-[#172c44] font-semibold">
                        ${court.pricePerHour.toLocaleString()}/hora
                      </p>
                      <p className="text-sm text-gray-600">
                        {court.bookingsToday} reservas hoy
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-1 text-sm text-gray-600">
                      <span>⭐ {court.rating}</span>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Editar
                      </Button>
                      <Button variant="outline" size="sm">
                        Horarios
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          {/* Tournaments Tab */}
          <TabsContent value="tournaments" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-[#172c44]">Torneos</h2>
              <Button 
                size="sm" 
                className="bg-[#f4b400] hover:bg-[#e6a200] text-[#172c44]"
                onClick={() => onNavigate('create-tournament')}
              >
                <Plus size={16} className="mr-2" />
                Crear Torneo
              </Button>
            </div>

            {tournaments.map((tournament) => (
              <Card key={tournament.id}>
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-[#172c44]">{tournament.name}</h3>
                        <Badge className={`text-xs ${getStatusColor(tournament.status)}`}>
                          {getStatusText(tournament.status)}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span>{tournament.sport}</span>
                        <span className="flex items-center gap-1">
                          <Users size={14} />
                          {tournament.participants} equipos
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar size={14} />
                          {tournament.startDate}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-[#172c44] font-semibold">
                        Premio: ${tournament.prize.toLocaleString()}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-1 text-sm text-[#00a884]">
                      <Trophy size={14} />
                      <span>Torneo activo</span>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => onNavigate('tournament-management', tournament)}
                      >
                        Ver Detalles
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => onNavigate('tournament-management', tournament)}
                      >
                        Gestionar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}