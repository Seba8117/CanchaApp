import { useState } from 'react';
import { User, Building, MapPin, Hash, Phone, Building2 } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import logoMain from 'figma:asset/09ec143ebc345d35acc5f9df4765c048fb08a12a.png';

interface LoginScreenProps {
  onLogin: (userType: 'player' | 'owner') => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [userType, setUserType] = useState<'player' | 'owner'>('player');
  
  // Common fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  // Player registration fields
  const [playerName, setPlayerName] = useState('');
  const [playerPhone, setPlayerPhone] = useState('');
  
  // Owner registration fields
  const [ownerName, setOwnerName] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [businessRut, setBusinessRut] = useState('');
  const [businessAddress, setBusinessAddress] = useState('');
  const [businessPhone, setBusinessPhone] = useState('');
  const [businessDescription, setBusinessDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin(userType);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#172c44] to-[#00a884] flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            <img 
              src={logoMain} 
              alt="CanchApp Logo" 
              className="w-16 h-16 mx-auto rounded-2xl shadow-lg"
            />
          </div>
          <CardTitle className="text-[#172c44] mb-2">
            {isLogin ? 'Bienvenido a CanchApp' : 'Únete a CanchApp'}
          </CardTitle>
          <p className="text-gray-600 text-sm">
            {isLogin ? 'Encuentra y organiza partidos cerca de ti' : 'La red social deportiva que buscabas'}
          </p>
        </CardHeader>
        
        <CardContent>
          {/* User Type Toggle - Always visible */}
          <div className="mb-6">
            <Tabs value={userType} onValueChange={(value: string) => setUserType(value as 'player' | 'owner')}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="player" className="flex items-center gap-2">
                  <User size={16} />
                  Jugador
                </TabsTrigger>
                <TabsTrigger value="owner" className="flex items-center gap-2">
                  <Building size={16} />
                  Dueño
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {isLogin ? (
            // Login Form
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                type="email"
                placeholder={userType === 'player' ? 'Correo electrónico' : 'Correo empresarial'}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="border-gray-200"
                required
              />
              <Input
                type="password"
                placeholder="Contraseña"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="border-gray-200"
                required
              />
              <Button 
                type="submit"
                className="w-full bg-[#f4b400] hover:bg-[#e6a200] text-[#172c44]"
              >
                Iniciar Sesión como {userType === 'player' ? 'Jugador' : 'Dueño'}
              </Button>
            </form>
          ) : (
            // Registration Forms
            <div className="space-y-4">
              {userType === 'player' ? (
                // Player Registration
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-3">
                    <Label className="text-[#172c44] flex items-center gap-2">
                      <User size={16} />
                      Información Personal
                    </Label>
                    <Input
                      type="text"
                      placeholder="Nombre completo"
                      value={playerName}
                      onChange={(e) => setPlayerName(e.target.value)}
                      className="border-gray-200"
                      required
                    />
                    <Input
                      type="email"
                      placeholder="Correo electrónico"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="border-gray-200"
                      required
                    />
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                      <Input
                        type="tel"
                        placeholder="Teléfono (opcional)"
                        value={playerPhone}
                        onChange={(e) => setPlayerPhone(e.target.value)}
                        className="border-gray-200 pl-10"
                      />
                    </div>
                    <Input
                      type="password"
                      placeholder="Contraseña"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="border-gray-200"
                      required
                    />
                  </div>
                  <Button 
                    type="submit"
                    className="w-full bg-[#00a884] hover:bg-[#00a884]/90 text-white"
                  >
                    Crear Cuenta de Jugador
                  </Button>
                </form>
              ) : (
                // Owner Registration
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-3">
                    <Label className="text-[#172c44] flex items-center gap-2">
                      <User size={16} />
                      Información Personal
                    </Label>
                    <Input
                      type="text"
                      placeholder="Nombre del propietario"
                      value={ownerName}
                      onChange={(e) => setOwnerName(e.target.value)}
                      className="border-gray-200"
                      required
                    />
                    <Input
                      type="email"
                      placeholder="Correo electrónico"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="border-gray-200"
                      required
                    />
                    <Input
                      type="password"
                      placeholder="Contraseña"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="border-gray-200"
                      required
                    />
                  </div>

                  <div className="space-y-3">
                    <Label className="text-[#172c44] flex items-center gap-2">
                      <Building2 size={16} />
                      Información del Negocio
                    </Label>
                    <Input
                      type="text"
                      placeholder="Nombre del complejo deportivo"
                      value={businessName}
                      onChange={(e) => setBusinessName(e.target.value)}
                      className="border-gray-200"
                      required
                    />
                    <div className="relative">
                      <Hash className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                      <Input
                        type="text"
                        placeholder="RUT de la empresa (ej: 12.345.678-9)"
                        value={businessRut}
                        onChange={(e) => setBusinessRut(e.target.value)}
                        className="border-gray-200 pl-10"
                        required
                      />
                    </div>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-3 text-gray-400" size={16} />
                      <Textarea
                        placeholder="Dirección completa del complejo"
                        value={businessAddress}
                        onChange={(e) => setBusinessAddress(e.target.value)}
                        className="border-gray-200 pl-10 min-h-[60px]"
                        required
                      />
                    </div>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
                      <Input
                        type="tel"
                        placeholder="Teléfono del negocio"
                        value={businessPhone}
                        onChange={(e) => setBusinessPhone(e.target.value)}
                        className="border-gray-200 pl-10"
                        required
                      />
                    </div>
                    <Textarea
                      placeholder="Descripción breve del complejo (opcional)"
                      value={businessDescription}
                      onChange={(e) => setBusinessDescription(e.target.value)}
                      className="border-gray-200 min-h-[60px]"
                    />
                  </div>
                  <Button 
                    type="submit"
                    className="w-full bg-[#f4b400] hover:bg-[#e6a200] text-[#172c44]"
                  >
                    Crear Cuenta de Negocio
                  </Button>
                </form>
              )}
            </div>
          )}

          {/* Toggle between login/register */}
          <div className="mt-6 text-center">
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-[#00a884] hover:underline"
            >
              {isLogin 
                ? '¿No tienes cuenta? Regístrate' 
                : '¿Ya tienes cuenta? Inicia sesión'
              }
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}