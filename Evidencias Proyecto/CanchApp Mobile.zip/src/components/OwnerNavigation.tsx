import { Building, Calendar, Trophy, BarChart3, User } from 'lucide-react';

interface OwnerNavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function OwnerNavigation({ activeTab, onTabChange }: OwnerNavigationProps) {
  const tabs = [
    { id: 'owner-dashboard', icon: BarChart3, label: 'Dashboard' },
    { id: 'owner-courts', icon: Building, label: 'Canchas' },
    { id: 'tournaments', icon: Trophy, label: 'Torneos' },
    { id: 'owner-profile', icon: User, label: 'Perfil' },
  ];

  return (
    <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-sm bg-white border-t border-gray-200 z-50">
      <div className="flex justify-around py-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`flex flex-col items-center py-2 px-3 rounded-lg transition-colors ${
                isActive 
                  ? 'text-[#00a884] bg-[#00a884]/10' 
                  : 'text-gray-500 hover:text-[#172c44]'
              }`}
            >
              <Icon size={20} />
              <span className="text-xs mt-1">{tab.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}