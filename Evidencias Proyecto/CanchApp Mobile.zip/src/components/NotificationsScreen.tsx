import { Bell, Users, Calendar, Trophy } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { AppHeader } from './AppHeader';

interface NotificationsScreenProps {
  onBack?: () => void;
}

export function NotificationsScreen({ onBack }: NotificationsScreenProps) {
  const notifications = [
    {
      id: 1,
      type: 'match',
      title: 'Nuevo partido disponible',
      message: 'Fútbol en Cancha Los Pinos - 19:00',
      time: 'Hace 5 min',
      read: false,
      icon: Calendar
    },
    {
      id: 2,
      type: 'team',
      title: 'Invitación a equipo',
      message: 'Los Tigres FC te invitó a unirte',
      time: 'Hace 1 hora',
      read: false,
      icon: Users
    },
    {
      id: 3,
      type: 'reminder',
      title: 'Recordatorio de partido',
      message: 'Tu partido es en 2 horas',
      time: 'Hace 2 horas',
      read: true,
      icon: Bell
    },
    {
      id: 4,
      type: 'tournament',
      title: 'Nuevo torneo disponible',
      message: 'Copa de Fútbol Santiago - Inscripciones abiertas',
      time: 'Ayer',
      read: true,
      icon: Trophy
    },
    {
      id: 5,
      type: 'match',
      title: 'Partido confirmado',
      message: 'Tu partido de mañana ha sido confirmado',
      time: 'Ayer',
      read: true,
      icon: Calendar
    }
  ];

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'match': return 'bg-blue-100 text-blue-700';
      case 'team': return 'bg-green-100 text-green-700';
      case 'tournament': return 'bg-purple-100 text-purple-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <AppHeader 
        title="Notificaciones" 
        showLogo={true}
        showBackButton={true}
        onBack={onBack}
        rightContent={
          <button className="text-[#00a884] text-sm">
            Marcar todas como leídas
          </button>
        }
      />

      <div className="p-4 space-y-3">
        {notifications.map((notification) => {
          const IconComponent = notification.icon;
          
          return (
            <Card 
              key={notification.id}
              className={`cursor-pointer hover:shadow-md transition-shadow ${
                !notification.read ? 'border-l-4 border-l-[#f4b400] bg-yellow-50/50' : ''
              }`}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-full ${getNotificationColor(notification.type)}`}>
                    <IconComponent size={16} />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start mb-1">
                      <h3 className={`${!notification.read ? 'text-[#172c44] font-medium' : 'text-[#172c44]'}`}>
                        {notification.title}
                      </h3>
                      {!notification.read && (
                        <div className="w-2 h-2 bg-[#f4b400] rounded-full flex-shrink-0 mt-2"></div>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{notification.message}</p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-500">{notification.time}</span>
                      <Badge 
                        variant="secondary"
                        className={`text-xs ${getNotificationColor(notification.type)}`}
                      >
                        {notification.type === 'match' ? 'Partido' :
                         notification.type === 'team' ? 'Equipo' :
                         notification.type === 'tournament' ? 'Torneo' : 'General'}
                      </Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}