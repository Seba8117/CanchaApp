import { useState } from 'react';
import { ArrowLeft, MapPin, Calendar, Clock, Users, DollarSign } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface CreateMatchScreenProps {
  onBack: () => void;
}

export function CreateMatchScreen({ onBack }: CreateMatchScreenProps) {
  const [step, setStep] = useState(1);
  const [selectedSport, setSelectedSport] = useState('');
  const [selectedCourt, setSelectedCourt] = useState('');

  const sports = [
    { id: 'football', name: 'Fútbol', icon: '⚽' },
    { id: 'basketball', name: 'Básquetball', icon: '🏀' },
    { id: 'tennis', name: 'Tenis', icon: '🎾' },
    { id: 'volleyball', name: 'Volleyball', icon: '🏐' },
    { id: 'padel', name: 'Pádel', icon: '🏓' },
    { id: 'futsal', name: 'Futsal', icon: '⚽' },
  ];

  const courts = [
    {
      id: 1,
      name: 'Cancha Los Pinos',
      location: 'Providencia',
      price: 25000,
      rating: 4.8,
      distance: '1.2 km'
    },
    {
      id: 2,
      name: 'Polideportivo Central',
      location: 'Santiago Centro',
      price: 18000,
      rating: 4.5,
      distance: '2.1 km'
    },
    {
      id: 3,
      name: 'Club Deportivo Norte',
      location: 'Las Condes',
      price: 35000,
      rating: 4.9,
      distance: '3.5 km'
    }
  ];

  const timeSlots = [
    '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00'
  ];

  const renderStep1 = () => (
    <div className="space-y-6">
      <h2 className="text-[#172c44] mb-4">¿Qué deporte quieres jugar?</h2>
      <div className="grid grid-cols-2 gap-3">
        {sports.map((sport) => (
          <button
            key={sport.id}
            onClick={() => setSelectedSport(sport.id)}
            className={`p-4 rounded-lg border-2 transition-colors ${
              selectedSport === sport.id
                ? 'border-[#f4b400] bg-[#f4b400]/10'
                : 'border-gray-200 bg-white'
            }`}
          >
            <div className="text-2xl mb-2">{sport.icon}</div>
            <p className="text-sm text-[#172c44]">{sport.name}</p>
          </button>
        ))}
      </div>
      <Button 
        onClick={() => setStep(2)}
        disabled={!selectedSport}
        className="w-full bg-[#f4b400] hover:bg-[#e6a200] text-[#172c44]"
      >
        Continuar
      </Button>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <h2 className="text-[#172c44] mb-4">Selecciona una cancha</h2>
      <div className="space-y-3">
        {courts.map((court) => (
          <Card 
            key={court.id}
            className={`cursor-pointer transition-colors ${
              selectedCourt === court.id.toString()
                ? 'border-[#f4b400] bg-[#f4b400]/5'
                : 'border-gray-200'
            }`}
            onClick={() => setSelectedCourt(court.id.toString())}
          >
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="text-[#172c44] mb-1">{court.name}</h3>
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <MapPin size={14} />
                      <span>{court.location} • {court.distance}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span>⭐ {court.rating}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-[#00a884]">${court.price.toLocaleString()}</p>
                  <p className="text-xs text-gray-600">por hora</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="flex gap-3">
        <Button 
          variant="outline" 
          onClick={() => setStep(1)}
          className="flex-1"
        >
          Atrás
        </Button>
        <Button 
          onClick={() => setStep(3)}
          disabled={!selectedCourt}
          className="flex-1 bg-[#f4b400] hover:bg-[#e6a200] text-[#172c44]"
        >
          Continuar
        </Button>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <h2 className="text-[#172c44] mb-4">Configura tu partido</h2>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm text-[#172c44] mb-2">
            Fecha del partido
          </label>
          <Input type="date" className="w-full" />
        </div>

        <div>
          <label className="block text-sm text-[#172c44] mb-2">
            Hora de inicio
          </label>
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Selecciona una hora" />
            </SelectTrigger>
            <SelectContent>
              {timeSlots.map((time) => (
                <SelectItem key={time} value={time}>
                  {time}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="block text-sm text-[#172c44] mb-2">
            Duración (horas)
          </label>
          <Select>
            <SelectTrigger>
              <SelectValue placeholder="Duración" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1 hora</SelectItem>
              <SelectItem value="1.5">1.5 horas</SelectItem>
              <SelectItem value="2">2 horas</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="block text-sm text-[#172c44] mb-2">
            Número de jugadores
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[6, 8, 10, 12, 14, 16].map((num) => (
              <Button
                key={num}
                variant="outline"
                className="aspect-square"
              >
                {num}
              </Button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm text-[#172c44] mb-2">
            Costo por jugador
          </label>
          <div className="relative">
            <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
            <Input 
              type="number" 
              placeholder="5000"
              className="pl-10"
            />
          </div>
        </div>

        <div>
          <label className="block text-sm text-[#172c44] mb-2">
            Descripción (opcional)
          </label>
          <Textarea 
            placeholder="Describe tu partido, nivel de juego, reglas especiales..."
            className="resize-none"
            rows={3}
          />
        </div>
      </div>

      <div className="flex gap-3">
        <Button 
          variant="outline" 
          onClick={() => setStep(2)}
          className="flex-1"
        >
          Atrás
        </Button>
        <Button 
          onClick={() => setStep(4)}
          className="flex-1 bg-[#f4b400] hover:bg-[#e6a200] text-[#172c44]"
        >
          Continuar
        </Button>
      </div>
    </div>
  );

  const renderStep4 = () => (
    <div className="space-y-6">
      <h2 className="text-[#172c44] mb-4">Confirma y publica</h2>
      
      <Card>
        <CardContent className="p-4 space-y-4">
          <div className="flex justify-between">
            <span className="text-gray-600">Deporte:</span>
            <span className="text-[#172c44]">Fútbol</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Cancha:</span>
            <span className="text-[#172c44]">Cancha Los Pinos</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Fecha:</span>
            <span className="text-[#172c44]">Mañana, 19:00</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Jugadores:</span>
            <span className="text-[#172c44]">10 personas</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Costo por persona:</span>
            <span className="text-[#00a884]">$5.000</span>
          </div>
          <div className="flex justify-between border-t pt-2">
            <span className="text-[#172c44]">Total arriendo cancha:</span>
            <span className="text-[#172c44]">$50.000</span>
          </div>
        </CardContent>
      </Card>

      <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
        <p className="text-sm text-yellow-800">
          <strong>Importante:</strong> Como capitán del equipo, serás responsable de coordinar el pago de la cancha. 
          Los jugadores pagarán su parte al unirse al partido.
        </p>
      </div>

      <div className="flex gap-3">
        <Button 
          variant="outline" 
          onClick={() => setStep(3)}
          className="flex-1"
        >
          Atrás
        </Button>
        <Button 
          onClick={onBack}
          className="flex-1 bg-[#00a884] hover:bg-[#008f73] text-white"
        >
          Publicar Partido
        </Button>
      </div>
    </div>
  );

  const renderCurrentStep = () => {
    switch (step) {
      case 1: return renderStep1();
      case 2: return renderStep2();
      case 3: return renderStep3();
      case 4: return renderStep4();
      default: return renderStep1();
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm">
        <div className="flex items-center justify-between p-4">
          <button onClick={onBack} className="p-2">
            <ArrowLeft className="text-[#172c44]" size={24} />
          </button>
          <h1 className="text-[#172c44]">Crear Partido</h1>
          <div className="w-8" />
        </div>
        
        {/* Progress bar */}
        <div className="px-4 pb-4">
          <div className="flex justify-between mb-2">
            {[1, 2, 3, 4].map((stepNum) => (
              <div
                key={stepNum}
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm ${
                  step >= stepNum
                    ? 'bg-[#f4b400] text-[#172c44]'
                    : 'bg-gray-200 text-gray-500'
                }`}
              >
                {stepNum}
              </div>
            ))}
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-[#f4b400] h-2 rounded-full transition-all duration-300"
              style={{ width: `${(step / 4) * 100}%` }}
            />
          </div>
        </div>
      </div>

      <div className="p-4">
        {renderCurrentStep()}
      </div>
    </div>
  );
}