import { Settings, Edit, Star, Building, Calendar, TrendingUp, MapPin, Phone, Mail, LogOut, AlertTriangle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';

interface OwnerProfileProps {
  onNavigate: (screen: string) => void;
  onLogout: () => void;
}

export function OwnerProfile({ onNavigate, onLogout }: OwnerProfileProps) {
  const ownerStats = {
    totalCourts: 5,
    totalBookings: 847,
    rating: 4.8,
    monthlyRevenue: 2850000,
    yearsInBusiness: 3,
    totalTournaments: 12
  };

  const businessInfo = {
    name: "Complejo Deportivo Los Pinos",
    ownerName: "María González",
    email: "maria@lospinos.cl",
    phone: "+56 9 8765 4321",
    address: "Av. Los Pinos 1234, Las Condes, Santiago",
    description: "Complejo deportivo moderno con canchas de última generación para fútbol, básquetball y tenis. Más de 3 años sirviendo a la comunidad deportiva.",
    founded: "2021",
    specialties: ["Fútbol", "Básquetball", "Tenis", "Torneos"]
  };

  const recentActivity = [
    {
      id: 1,
      type: 'booking',
      description: 'Nueva reserva en Cancha Principal',
      time: 'Hace 2 horas',
      amount: 50000
    },
    {
      id: 2,
      type: 'tournament',
      description: 'Inscripción al Torneo Copa Primavera',
      time: 'Hace 4 horas',
      amount: null
    },
    {
      id: 3,
      type: 'review',
      description: 'Nueva reseña de 5 estrellas',
      time: 'Hace 1 día',
      amount: null
    },
    {
      id: 4,
      type: 'booking',
      description: 'Reserva completada - Cancha Tenis Norte',
      time: 'Hace 1 día',
      amount: 30000
    }
  ];

  const achievements = [
    { id: 1, title: 'Primer Mes', description: 'Completaste tu primer mes', icon: '🎉', unlocked: true },
    { id: 2, title: 'Popular', description: '100 reservas completadas', icon: '⭐', unlocked: true },
    { id: 3, title: 'Organizador', description: 'Creaste 5 torneos', icon: '🏆', unlocked: true },
    { id: 4, title: 'Cinco Estrellas', description: 'Mantén 4.5+ rating por 3 meses', icon: '🌟', unlocked: true },
    { id: 5, title: 'Empresario', description: 'Genera $1M+ en un mes', icon: '💰', unlocked: false },
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'booking': return '📅';
      case 'tournament': return '🏆';
      case 'review': return '⭐';
      default: return '📌';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#172c44] to-[#00a884] text-white p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-4">
            <Avatar className="w-16 h-16">
              <AvatarFallback className="bg-[#f4b400] text-[#172c44] text-xl">
                MG
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-xl mb-1">{businessInfo.ownerName}</h1>
              <p className="text-sm opacity-90">{businessInfo.name}</p>
              <div className="flex items-center gap-2 mt-1">
                <div className="flex items-center gap-1">
                  <Star className="text-[#f4b400]" size={16} fill="currentColor" />
                  <span>{ownerStats.rating}</span>
                </div>
                <span className="text-sm opacity-80">{ownerStats.totalBookings} reservas</span>
              </div>
            </div>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-white"
            onClick={() => onNavigate('edit-owner-profile')}
          >
            <Settings size={20} />
          </Button>
        </div>

        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <p className="text-2xl font-bold">{ownerStats.totalCourts}</p>
            <p className="text-sm opacity-80">Canchas</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold">{ownerStats.totalTournaments}</p>
            <p className="text-sm opacity-80">Torneos</p>
          </div>
          <div className="text-center">
            <p className="text-lg font-bold">${(ownerStats.monthlyRevenue / 1000000).toFixed(1)}M</p>
            <p className="text-sm opacity-80">Ingresos/mes</p>
          </div>
        </div>
      </div>

      <div className="p-4">
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Resumen</TabsTrigger>
            <TabsTrigger value="business">Negocio</TabsTrigger>
            <TabsTrigger value="activity">Actividad</TabsTrigger>
            <TabsTrigger value="achievements">Logros</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-[#172c44] flex items-center gap-2">
                  <Building size={20} />
                  Información del Negocio
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-600">Canchas Activas</p>
                    <p className="text-[#172c44]">{ownerStats.totalCourts}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Años en Servicio</p>
                    <p className="text-[#172c44]">{ownerStats.yearsInBusiness} años</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Rating Promedio</p>
                    <p className="text-[#172c44]">{ownerStats.rating} ⭐</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Fundado</p>
                    <p className="text-[#172c44]">{businessInfo.founded}</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <Button 
                    variant="outline" 
                    className="w-full text-[#00a884] border-[#00a884]"
                    onClick={() => onNavigate('edit-owner-profile')}
                  >
                    <Edit size={16} className="mr-2" />
                    Editar Perfil del Negocio
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full text-orange-600 border-orange-300 hover:bg-orange-50"
                    onClick={() => onNavigate('report-team')}
                  >
                    <AlertTriangle size={16} className="mr-2" />
                    Reportar Equipo
                  </Button>
                  
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button 
                        variant="outline" 
                        className="w-full text-red-600 border-red-300 hover:bg-red-50"
                      >
                        <LogOut size={16} className="mr-2" />
                        Cerrar Sesión
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>¿Cerrar sesión?</AlertDialogTitle>
                        <AlertDialogDescription>
                          ¿Estás seguro que quieres cerrar tu sesión empresarial? Tendrás que volver a iniciar sesión para gestionar tu negocio.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancelar</AlertDialogCancel>
                        <AlertDialogAction 
                          onClick={onLogout}
                          className="bg-red-600 hover:bg-red-700 text-white"
                        >
                          Cerrar Sesión
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-[#172c44]">Especialidades</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {businessInfo.specialties.map((specialty, index) => (
                    <Badge key={index} className="bg-[#00a884] text-white">
                      {specialty}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Business Tab */}
          <TabsContent value="business" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-[#172c44] flex items-center gap-2">
                  <Building size={20} />
                  Datos del Complejo
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600">Nombre del Negocio</p>
                  <p className="text-[#172c44]">{businessInfo.name}</p>
                </div>
                
                <div className="flex items-start gap-3">
                  <MapPin size={16} className="text-gray-400 mt-1" />
                  <div className="flex-1">
                    <p className="text-sm text-gray-600">Dirección</p>
                    <p className="text-[#172c44]">{businessInfo.address}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail size={16} className="text-gray-400 mt-1" />
                  <div className="flex-1">
                    <p className="text-sm text-gray-600">Correo Electrónico</p>
                    <p className="text-[#172c44]">{businessInfo.email}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone size={16} className="text-gray-400 mt-1" />
                  <div className="flex-1">
                    <p className="text-sm text-gray-600">Teléfono</p>
                    <p className="text-[#172c44]">{businessInfo.phone}</p>
                  </div>
                </div>

                <div>
                  <p className="text-sm text-gray-600">Descripción</p>
                  <p className="text-[#172c44] text-sm leading-relaxed">{businessInfo.description}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-[#172c44] flex items-center gap-2">
                  <TrendingUp size={20} />
                  Estadísticas del Mes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Ingresos Totales</span>
                    <span className="text-[#172c44] font-semibold">
                      ${ownerStats.monthlyRevenue.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Reservas Completadas</span>
                    <span className="text-[#172c44] font-semibold">{ownerStats.totalBookings}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Torneos Organizados</span>
                    <span className="text-[#172c44] font-semibold">{ownerStats.totalTournaments}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent value="activity" className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-[#172c44]">Actividad Reciente</h2>
              <Button variant="ghost" size="sm" className="text-[#00a884]">
                Ver Historial
              </Button>
            </div>

            {recentActivity.map((activity) => (
              <Card key={activity.id}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="text-2xl">{getActivityIcon(activity.type)}</div>
                    <div className="flex-1">
                      <p className="text-[#172c44]">{activity.description}</p>
                      <p className="text-sm text-gray-600">{activity.time}</p>
                    </div>
                    {activity.amount && (
                      <div className="text-right">
                        <p className="text-[#00a884] font-semibold">
                          +${activity.amount.toLocaleString()}
                        </p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-4">
            <h2 className="text-[#172c44]">Logros Empresariales</h2>
            
            <div className="grid gap-3">
              {achievements.map((achievement) => (
                <Card 
                  key={achievement.id}
                  className={`${achievement.unlocked ? 'bg-white' : 'bg-gray-50 opacity-60'}`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className={`text-2xl ${achievement.unlocked ? '' : 'grayscale'}`}>
                        {achievement.icon}
                      </div>
                      <div className="flex-1">
                        <h3 className={`${achievement.unlocked ? 'text-[#172c44]' : 'text-gray-500'}`}>
                          {achievement.title}
                        </h3>
                        <p className="text-sm text-gray-600">{achievement.description}</p>
                      </div>
                      {achievement.unlocked && (
                        <div className="w-6 h-6 bg-[#00a884] rounded-full flex items-center justify-center">
                          <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}