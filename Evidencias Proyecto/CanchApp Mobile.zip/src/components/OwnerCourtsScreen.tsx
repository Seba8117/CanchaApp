import { Building, Plus, Users, Clock, Star, Settings } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { AppHeader } from './AppHeader';

interface OwnerCourtsScreenProps {
  onNavigate: (screen: string, data?: any) => void;
}

export function OwnerCourtsScreen({ onNavigate }: OwnerCourtsScreenProps) {
  const courts = [
    {
      id: 1,
      name: 'Cancha Principal',
      sport: 'Fútbol',
      surface: 'Césped sintético',
      capacity: 22,
      pricePerHour: 25000,
      status: 'available',
      bookingsToday: 6,
      bookingsWeek: 28,
      rating: 4.8,
      totalReviews: 47,
      images: 3,
      amenities: ['Iluminación LED', 'Vestuarios', 'Estacionamiento']
    },
    {
      id: 2,
      name: 'Cancha Básquetball',
      sport: 'Básquetball',
      surface: 'Madera',
      capacity: 10,
      pricePerHour: 20000,
      status: 'occupied',
      bookingsToday: 4,
      bookingsWeek: 18,
      rating: 4.6,
      totalReviews: 32,
      images: 2,
      amenities: ['Aire acondicionado', 'Vestuarios', 'Tribuna']
    },
    {
      id: 3,
      name: 'Cancha Tenis Norte',
      sport: 'Tenis',
      surface: 'Arcilla',
      capacity: 4,
      pricePerHour: 15000,
      status: 'maintenance',
      bookingsToday: 0,
      bookingsWeek: 12,
      rating: 4.9,
      totalReviews: 28,
      images: 4,
      amenities: ['Iluminación nocturna', 'Graderías']
    },
    {
      id: 4,
      name: 'Cancha Fútbol 7',
      sport: 'Fútbol',
      surface: 'Césped natural',
      capacity: 14,
      pricePerHour: 22000,
      status: 'available',
      bookingsToday: 3,
      bookingsWeek: 15,
      rating: 4.7,
      totalReviews: 39,
      images: 3,
      amenities: ['Vestuarios', 'Parrillas', 'Estacionamiento']
    },
    {
      id: 5,
      name: 'Cancha Tenis Sur',
      sport: 'Tenis',
      surface: 'Cemento',
      capacity: 4,
      pricePerHour: 12000,
      status: 'available',
      bookingsToday: 2,
      bookingsWeek: 8,
      rating: 4.5,
      totalReviews: 21,
      images: 2,
      amenities: ['Iluminación básica']
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available': return 'bg-green-100 text-green-700';
      case 'occupied': return 'bg-red-100 text-red-700';
      case 'maintenance': return 'bg-yellow-100 text-yellow-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'available': return 'Disponible';
      case 'occupied': return 'Ocupada';
      case 'maintenance': return 'Mantenimiento';
      default: return status;
    }
  };

  const getSportIcon = (sport: string) => {
    switch (sport) {
      case 'Fútbol': return '⚽';
      case 'Básquetball': return '🏀';
      case 'Tenis': return '🎾';
      default: return '🏟️';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <AppHeader 
        title="Mis Canchas" 
        showLogo={true}
        rightContent={
          <Button 
            size="sm" 
            className="bg-[#00a884] hover:bg-[#00a884]/90 text-white"
            onClick={() => onNavigate('add-court')}
          >
            <Plus size={16} className="mr-2" />
            Agregar
          </Button>
        }
      />

      <div className="p-4 space-y-4">
        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3">
          <Card className="bg-[#00a884] text-white">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold">{courts.length}</p>
              <p className="text-sm opacity-90">Canchas</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#f4b400] text-[#172c44]">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold">
                {courts.reduce((acc, court) => acc + court.bookingsToday, 0)}
              </p>
              <p className="text-sm opacity-90">Hoy</p>
            </CardContent>
          </Card>
          
          <Card className="bg-[#172c44] text-white">
            <CardContent className="p-4 text-center">
              <p className="text-2xl font-bold">
                {(courts.reduce((acc, court) => acc + court.rating, 0) / courts.length).toFixed(1)}
              </p>
              <p className="text-sm opacity-90">Rating</p>
            </CardContent>
          </Card>
        </div>

        {/* Courts List */}
        <div className="space-y-3">
          {courts.map((court) => (
            <Card key={court.id}>
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xl">{getSportIcon(court.sport)}</span>
                      <h3 className="text-[#172c44] font-semibold">{court.name}</h3>
                      <Badge className={`text-xs ${getStatusColor(court.status)}`}>
                        {getStatusText(court.status)}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm text-gray-600 mb-2">
                      <span>{court.sport}</span>
                      <span>{court.surface}</span>
                      <span className="flex items-center gap-1">
                        <Users size={14} />
                        {court.capacity}
                      </span>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <span className="flex items-center gap-1">
                        <Star size={14} className="text-[#f4b400]" fill="currentColor" />
                        {court.rating} ({court.totalReviews})
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock size={14} />
                        {court.bookingsToday} hoy
                      </span>
                      <span>{court.bookingsWeek} esta semana</span>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-[#172c44] font-bold text-lg">
                      ${court.pricePerHour.toLocaleString()}
                    </p>
                    <p className="text-sm text-gray-600">por hora</p>
                  </div>
                </div>

                {/* Amenities */}
                <div className="mb-3">
                  <div className="flex flex-wrap gap-1">
                    {court.amenities.slice(0, 3).map((amenity, index) => (
                      <Badge key={index} variant="secondary" className="text-xs bg-gray-100 text-gray-700">
                        {amenity}
                      </Badge>
                    ))}
                    {court.amenities.length > 3 && (
                      <Badge variant="secondary" className="text-xs bg-gray-100 text-gray-700">
                        +{court.amenities.length - 3} más
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => onNavigate('court-detail', court)}
                  >
                    Ver Detalles
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => onNavigate('court-schedule', court)}
                  >
                    Horarios
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    onClick={() => onNavigate('court-settings', court)}
                  >
                    <Settings size={16} />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Add Court Button */}
        <Card className="border-2 border-dashed border-gray-300 hover:border-[#00a884] transition-colors">
          <CardContent className="p-6">
            <Button 
              variant="ghost" 
              className="w-full h-16 text-[#00a884] hover:text-[#00a884] hover:bg-[#00a884]/10"
              onClick={() => onNavigate('add-court')}
            >
              <div className="flex flex-col items-center gap-2">
                <Plus size={24} />
                <span>Agregar Nueva Cancha</span>
              </div>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}