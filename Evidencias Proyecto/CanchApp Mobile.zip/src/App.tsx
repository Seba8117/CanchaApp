import { useState } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { HomeScreen } from './components/HomeScreen';
import { MatchDetailScreen } from './components/MatchDetailScreen';
import { CreateMatchScreen } from './components/CreateMatchScreen';
import { SearchScreen } from './components/SearchScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { ChatScreen } from './components/ChatScreen';
import { NotificationsScreen } from './components/NotificationsScreen';
import { TournamentsScreen } from './components/TournamentsScreen';
import { EditProfileScreen } from './components/EditProfileScreen';
import { OwnerDashboard } from './components/OwnerDashboard';
import { OwnerProfile } from './components/OwnerProfile';
import { OwnerCourtsScreen } from './components/OwnerCourtsScreen';
import { EditOwnerProfileScreen } from './components/EditOwnerProfileScreen';
import { AddCourtScreen } from './components/AddCourtScreen';
import { CreateTournamentScreen } from './components/CreateTournamentScreen';
import { TournamentManagementScreen } from './components/TournamentManagementScreen';
import { TeamDetailsScreen } from './components/TeamDetailsScreen';
import { TournamentDetailScreen } from './components/TournamentDetailScreen';
import { MatchPlayersScreen } from './components/MatchPlayersScreen';
import { ReportPlayerScreen } from './components/ReportPlayerScreen';
import { ReportTeamScreen } from './components/ReportTeamScreen';
import { Navigation } from './components/Navigation';
import { OwnerNavigation } from './components/OwnerNavigation';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userType, setUserType] = useState<'player' | 'owner'>('player');
  const [currentScreen, setCurrentScreen] = useState('home');
  const [screenData, setScreenData] = useState<any>(null);

  const handleLogin = (type: 'player' | 'owner') => {
    setIsLoggedIn(true);
    setUserType(type);
    // Set different initial screens based on user type
    setCurrentScreen(type === 'owner' ? 'owner-dashboard' : 'home');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserType('player');
    setCurrentScreen('home');
    setScreenData(null);
  };

  const handleNavigate = (screen: string, data?: any) => {
    setCurrentScreen(screen);
    setScreenData(data);
  };

  const handleBack = () => {
    // Return to appropriate default screen based on user type
    setCurrentScreen(userType === 'owner' ? 'owner-dashboard' : 'home');
    setScreenData(null);
  };

  if (!isLoggedIn) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  const renderScreen = () => {
    // Common screens for both user types
    switch (currentScreen) {
      case 'tournaments':
        return <TournamentsScreen onBack={handleBack} onNavigate={handleNavigate} userType={userType} />;
      case 'tournament-detail':
        return <TournamentDetailScreen onBack={handleBack} tournament={screenData} userType={userType} />;
      case 'match-players':
        return <MatchPlayersScreen match={screenData} onBack={handleBack} onNavigate={handleNavigate} userType={userType} />;
      case 'report-player':
        return <ReportPlayerScreen playerData={screenData} onBack={handleBack} />;
      case 'report-team':
        return <ReportTeamScreen teamData={screenData} onBack={handleBack} />;
      case 'notifications':
        return <NotificationsScreen onBack={handleBack} />;
      case 'chat':
        return <ChatScreen onBack={handleBack} />;
      default:
        break;
    }

    // Player-specific screens
    if (userType === 'player') {
      switch (currentScreen) {
        case 'home':
          return <HomeScreen onNavigate={handleNavigate} />;
        case 'match-detail':
          return <MatchDetailScreen match={screenData} onBack={handleBack} onNavigate={handleNavigate} userType={userType} />;
        case 'create':
          return <CreateMatchScreen onBack={handleBack} />;
        case 'search':
          return <SearchScreen onNavigate={handleNavigate} />;
        case 'profile':
          return <ProfileScreen onNavigate={handleNavigate} onLogout={handleLogout} />;
        case 'edit-profile':
          return <EditProfileScreen onBack={handleBack} />;
        default:
          return <HomeScreen onNavigate={handleNavigate} />;
      }
    }

    // Owner-specific screens
    if (userType === 'owner') {
      switch (currentScreen) {
        case 'owner-dashboard':
          return <OwnerDashboard onNavigate={handleNavigate} onLogout={handleLogout} />;
        case 'owner-courts':
          return <OwnerCourtsScreen onNavigate={handleNavigate} />;
        case 'owner-profile':
          return <OwnerProfile onNavigate={handleNavigate} onLogout={handleLogout} />;
        case 'edit-owner-profile':
          return <EditOwnerProfileScreen onBack={handleBack} />;
        case 'add-court':
          return <AddCourtScreen onBack={handleBack} onNavigate={handleNavigate} />;
        case 'create-tournament':
          return <CreateTournamentScreen onBack={handleBack} onNavigate={handleNavigate} />;
        case 'tournament-management':
          return <TournamentManagementScreen onBack={handleBack} onNavigate={handleNavigate} tournament={screenData} />;
        case 'team-details':
          return <TeamDetailsScreen onBack={handleBack} teamData={screenData} />;
        default:
          return <OwnerDashboard onNavigate={handleNavigate} onLogout={handleLogout} />;
      }
    }

    // Fallback
    return userType === 'owner' 
      ? <OwnerDashboard onNavigate={handleNavigate} />
      : <HomeScreen onNavigate={handleNavigate} />;
  };

  const showNavigation = !['match-detail', 'create', 'chat', 'notifications', 'tournaments', 'tournament-detail', 'edit-profile', 'edit-owner-profile', 'add-court', 'create-tournament', 'tournament-management', 'team-details', 'match-players', 'report-player', 'report-team'].includes(currentScreen);

  return (
    <div className="max-w-sm mx-auto bg-white min-h-screen relative">
      {renderScreen()}
      {showNavigation && userType === 'player' && (
        <Navigation 
          activeTab={currentScreen} 
          onTabChange={setCurrentScreen} 
        />
      )}
      {showNavigation && userType === 'owner' && (
        <OwnerNavigation 
          activeTab={currentScreen} 
          onTabChange={setCurrentScreen} 
        />
      )}
    </div>
  );
}